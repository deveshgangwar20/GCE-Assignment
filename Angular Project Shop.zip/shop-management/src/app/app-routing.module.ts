import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { ShopComponent } from './components/shop/shop.component';
import { AddshopComponent } from './components/addshop/addshop.component';

const routes:Routes=[
  { path: '', redirectTo: '/listshop', pathMatch: 'full' },
  {path:'listshop',component:ShopComponent},
  {path:'addshop',component:AddshopComponent}];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
