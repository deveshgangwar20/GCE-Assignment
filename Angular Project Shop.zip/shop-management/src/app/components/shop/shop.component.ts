import { Component, OnInit } from '@angular/core';
import { Shop } from '../../shop';
import { ShopService } from '../../shared_service/shop.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-shop',
  templateUrl: './shop.component.html',
  styleUrls: ['./shop.component.css']
})
export class ShopComponent implements OnInit {

  shops:Shop[];
  selectedShop:Shop;
    
  constructor(private _httpClientService:ShopService,private _router :Router) { }

  ngOnInit() {
    console.log('init call');
    this._httpClientService.getShops().subscribe(response =>this.shops=response);
  }

deleteShop(shop: Shop): void {
  this._httpClientService.deleteShop(shop).subscribe( data => {this.shops = this.shops.filter(u => u !== shop);})
}

editShop(shop: Shop): void {
  this.selectedShop=shop;
  console.log(this.selectedShop);

}

}
