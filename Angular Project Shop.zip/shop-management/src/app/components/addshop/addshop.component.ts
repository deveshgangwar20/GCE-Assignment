import { Component, OnInit } from '@angular/core';
import { Shop } from '../../shop';
import { ShopService } from '../../shared_service/shop.service';
import {Router} from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

export interface Category {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-addshop',
  templateUrl: './addshop.component.html',
  styleUrls: ['./addshop.component.css']
})
export class AddshopComponent implements OnInit {
  shop:Shop=new Shop();
  
  categories: Category[] = [
    {value: 'General Store', viewValue: 'General Store'},
    {value: 'Mall', viewValue: 'Mall'},
    {value: 'Medical Store', viewValue: 'Medical Store'},
    {value: 'Supermarket', viewValue: 'Supermarket'}    
  ];
  registerForm: FormGroup;
  submitted = false;

  constructor(private formBuilder: FormBuilder,private _httpservice: ShopService,private _router:Router) { }

  ngOnInit() {
      this.registerForm = this.formBuilder.group({
          shopName: ['', [Validators.required,Validators.minLength(5)]],
          location: ['', [Validators.required,Validators.minLength(5)]],
          ownerName: ['', [Validators.required,Validators.minLength(5)]],
          category: ['', Validators.required]         
      });
  }
  
  onSubmit() {
    this.submitted = true;
    
    if (this.registerForm.invalid) {
        return;
    }    
    this.shop.name=this.registerForm.value.shopName;
    this.shop.category=this.registerForm.value.category;
    this.shop.location=this.registerForm.value.location;
    this.shop.ownerName=this.registerForm.value.ownerName;
    this.save();
}
save(){ 
   this._httpservice.createShop(this.shop).subscribe(data => {  
    this._router.navigate(['listshop']);  
  },  
  error => {  
    alert(error);  
  });   
}

get f() { 
  return this.registerForm.controls; }
 }
