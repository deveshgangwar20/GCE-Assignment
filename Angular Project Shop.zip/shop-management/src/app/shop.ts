export class Shop {
    public id:number;
    public name:string;
    public category:string;
    public location:string;
    public ownerName:string;
}
