import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Shop } from '../shop';

@Injectable({
  providedIn: 'root'
})
export class ShopService {
  baseurl:string='http://localhost:8081/shop/api';
  constructor(private httpClient:HttpClient) { 
   }

   getShops() {
    console.log("getShops");
    return this.httpClient.get<Shop[]>(this.baseurl+'/shops');
  }

public deleteShop(shop) {
  console.log("deleteShop");
  return this.httpClient.delete<Shop>(this.baseurl+'/shop/' + shop.id);
}

public createShop(shop) {
  console.log('createShop :'+shop.name);
  return this.httpClient.post<Shop>(this.baseurl+'/shop/', shop);
}

public updateShop(shop) {
  console.log('updateShop :'+shop.id);
  return this.httpClient.put<Shop>(this.baseurl+'/shop/', shop).subscribe(data  => {
    console.log("PUT Request is successful ", data);
    }, error  => {console.log("Rrror", error);});
}
}